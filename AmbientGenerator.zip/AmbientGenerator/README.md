# Ambient Music Generator - iOS Final Project
## Important Information
This project is using a dependency management package called CocoaPods, so the git repo may not function correctly without the proper setup. Currently, Keenan is working on a shell script to make setup as ease as running the script. For now, the `.zip` requested for the milestone assignment will contain all needed dependencies to ensure that the project runs correctly. Please make sure you are running the project using the `.xcworkspace` file included in the `.zip`.

### Group Members
* Keenan Piveral-Brooks - s527356@nwmissouri.edu
* Sai Manikanta Durga Prasad - s533980@nwmissouri.edu
* Venkata Ajit Kumar Dokka - S531497@nwmissouri.edu
* Srikar Patle - s533986@nwmissouri.edu

### Overview
This app, the ambient music generator, would be an application designed to generate infinite pseudo random ambient tunes, to underscore a study session, a low key party, or for any time you just need a little background noise.

